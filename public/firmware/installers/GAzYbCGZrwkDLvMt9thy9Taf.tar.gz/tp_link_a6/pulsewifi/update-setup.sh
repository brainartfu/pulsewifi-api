api=$(uci get zaytech.@node[0].api)
key=$(uci get zaytech.@node[0].key)
secret=$(uci get zaytech.@node[0].secret)
zero=""

cd /tmp
rm /tmp/update.sh

version=$(wget -qO- "http://$api/api/location/wifi-routers/firmware/config/$key/$secret/version")
echo $version

if [ -z "${version##*$key*}" ] && [ "$key" != "$zero" ] && [ "$version" != "$zero" ]
then
        version=$(echo $version | sed "s/$key$//")
	echo "Inside"
        if [ "$version" != "$zero" ]
        then
		echo "Inside If"
                original_version=$(uci get zaytech.@node[0].version)
                if [ "$version" != "$original_version" ]
                then
			echo "inside iff"
                        uci set zaytech.@node[0].version="$version"
                fi
        fi
else
        echo 'NO'
fi

radius_server=$(wget -qO- "http://$api/api/location/wifi-routers/firmware/config/$key/$secret/radius_server")
echo $radius_server

if [ -z "${radius_server##*$key*}" ] && [ "$key" != "$zero" ] && [ "$radius_server" != "$zero" ]
then
        radius_server=$(echo $radius_server | sed "s/$key$//")

        if [ "$radius_server" != "$zero" ]
        then
                original_radius_server=$(uci get zaytech.@node[0].radius_server)
                if [ "$radius_server" != "$original_radius_server" ]
                then
                        uci set zaytech.@node[0].radius_server="$radius_server"
                fi
        fi
else
        echo 'NO'
fi

radius_secret=$(wget -qO- "http://$api/api/location/wifi-routers/firmware/config/$key/$secret/radius_secret")
echo $radius_secret

if [ -z "${radius_secret##*$key*}" ] && [ "$key" != "$zero" ] && [ "$radius_secret" != "$zero" ]
then
        radius_secret=$(echo $radius_secret | sed "s/$key$//")

        if [ "$radius_secret" != "$zero" ]
        then
                original_radius_secret=$(uci get zaytech.@node[0].radius_secret)
                if [ "$radius_secret" != "$original_radius_secret" ]
                then
                        uci set zaytech.@node[0].radius_secret="$radius_secret"
                fi
        fi
else
        echo 'NO'
fi

uam_secret=$(wget -qO- "http://$api/api/location/wifi-routers/firmware/config/$key/$secret/uam_secret")
echo "http://$api/api/location/wifi-routers/firmware/config/$key/$secret/uam_secret"
echo "UAM Secret $uam_secret"

if [ -z "${uam_secret##*$key*}" ] && [ "$key" != "$zero" ] && [ "$uam_secret" != "$zero" ]
then
        uam_secret=$(echo $uam_secret | sed "s/$key$//")

        if [ "$uam_secret" != "$zero" ]
        then
                original_uam_secret=$(uci get zaytech.@node[0].uam_secret)
                if [ "$uam_secret" != "$original_uam_secret" ]
                then
                        uci set zaytech.@node[0].uam_secret="$uam_secret"
                fi
        fi
else
        echo 'NO'
fi

whitelist=$(wget -qO- "http://$api/api/location/wifi-routers/firmware/config/$key/$secret/whitelist")
echo $whitelist

if [ -z "${whitelist##*$key*}" ] && [ "$key" != "$zero" ] && [ "$whitelist" != "$zero" ]
then
        whitelist=$(echo $whitelist | sed "s/$key$//")

        if [ "$whitelist" != "$zero" ]
        then
                original_whitelist=$(uci get zaytech.@node[0].whitelist)
                if [ "$whitelist" != "$original_whitelist" ]
                then
                        uci set zaytech.@node[0].whitelist="$whitelist"
                fi
        fi
else
        echo 'NO'
fi

domainWhitelist=$(wget -qO- "http://$api/api/location/wifi-routers/firmware/config/$key/$secret/domain-whitelist")
echo $domainWhitelist

if [ -z "${domainWhitelist##*$key*}" ] && [ "$key" != "$zero" ] && [ "$domainWhitelist" != "$zero" ]
then
        domainWhitelist=$(echo $domainWhitelist | sed "s/$key$//")

        if [ "$domainWhitelist" != "$zero" ]
        then
                original_domainWhitelist=$(uci get zaytech.@node[0].domainWhitelist)
                if [ "$domainWhitelist" != "$original_domainWhitelist" ]
                then
                        uci set zaytech.@node[0].domainWhitelist="$domainWhitelist"
                fi
        fi
else
        echo 'NO'
fi

nasid=$(wget -qO- "http://$api/api/location/wifi-routers/firmware/config/$key/$secret/nasid")
echo $nasid

if [ -z "${nasid##*$key*}" ] && [ "$key" != "$zero" ] && [ "$nasid" != "$zero" ]
then
        nasid=$(echo $nasid | sed "s/$key$//")

        if [ "$nasid" != "$zero" ]
        then
                original_nasid=$(uci get zaytech.@node[0].nasid)
                if [ "$nasid" != "$original_nasid" ]
                then
                        uci set zaytech.@node[0].nasid="$nasid"
                fi
        fi
else
        echo 'NO'
fi

model=$(wget -qO- "http://$api/api/location/wifi-routers/firmware/config/$key/$secret/model")
echo $model

if [ -z "${model##*$key*}" ] && [ "$key" != "$zero" ] && [ "$model" != "$zero" ]
then
        model=$(echo $model | sed "s/$key$//")

        if [ "$model" != "$zero" ]
        then
                original_model=$(uci get zaytech.@node[0].model)
                if [ "$nasid" != "$original_model" ]
                then
                        uci set zaytech.@node[0].model="$model"
                fi
        fi
else
        echo 'NO'
fi


login_url=$(wget -qO- "http://$api/api/location/wifi-routers/firmware/config/$key/$secret/login_url")
if [ -z "${login_url##*$key*}" ] && [ "$key" != "$zero" ] && [ "$login_url" != "$zero" ]
then                                     
        login_url=$(echo $login_url | sed "s/$key$//")

        if [ "$login_url" != "$zero" ]
        then
                original_login_url=$(uci get zaytech.@node[0].login_url)
                if [ "$login_url" != "$original_login_url" ]                             
                then
                        uci set zaytech.@node[0].login_url="$login_url"                          
                fi
        fi
else                                                                                
        echo 'NO'
fi  


guest_essid=$(wget -qO- "http://$api/api/location/wifi-routers/firmware/config/$key/$secret/guest_essid")
if [ -z "${guest_essid##*$key*}" ] && [ "$key" != "$zero" ] && [ "$guest_essid" != "$zero" ]
then
        guest_essid=$(echo $guest_essid | sed "s/$key$//")

        if [ "$guest_essid" != "$zero" ]
        then
                original_guest_essid=$(uci get zaytech.@node[0].guest_essid)
                if [ "$guest_essid" != "$original_guest_essid" ]                             
                then
                        uci set zaytech.@node[0].guest_essid="$guest_essid"                          
                fi
        fi
else                                                                                
        echo 'NO'
fi  

update_script=$(wget -qO- "http://$api/api/location/wifi-routers/firmware/config/$key/$secret/update_script")
if [ -z "${update_script##*$key*}" ] && [ "$key" != "$zero" ] && [ "$update_script" != "$zero" ]
then
        update_script=$(echo $update_script | sed "s/$key$//")

        if [ "$update_script" != "$zero" ]
        then
                original_update_script=$(uci get zaytech.@node[0].update_script)
                if [ "$update_script" != "$original_update_script" ]
                then 
                        update="http://api.zayfi.com/firmware/updates/$update_script"
                        echo "update:: $update"
                        wget $update -O update.sh
                        uci set zaytech.@node[0].update_script="$update_script" 
                fi 
        fi
else                                                                                
        echo 'NO'
fi

uci set zaytech.@node[0].dns1="8.8.8.8"
uci set zaytech.@node[0].dns2="8.8.4.4"

uci commit zaytech

uci set chilli.@chilli[0].radiusserver1=$(uci get zaytech.@node[0].radius_server)
uci set chilli.@chilli[0].radiusserver2=$(uci get zaytech.@node[0].radius_server)
uci set chilli.@chilli[0].radiussecret=$(uci get zaytech.@node[0].radius_secret)
uci set chilli.@chilli[0].uamserver=$(uci get zaytech.@node[0].login_url)
#uci set chilli.@chilli[0].uamsecret=$(uci get zaytech.@node[0].uam_secret)
uci set chilli.@chilli[0].uamsecret=''
uci set chilli.@chilli[0].dns1=$(uci get zaytech.@node[0].dns1)
uci set chilli.@chilli[0].dns2=$(uci get zaytech.@node[0].dns2)
uci set chilli.@chilli[0].radiusnasid=$(uci get zaytech.@node[0].nasid)
uci set chilli.@chilli[0].uamallowed=$(uci get zaytech.@node[0].whitelist)
uci set chilli.@chilli[0].dns1=$(uci get zaytech.@node[0].dns1)
uci set chilli.@chilli[0].dns2=$(uci get zaytech.@node[0].dns2)
uci set chilli.@chilli[0].uamdomain=$(uci get zaytech.@node[0].domainWhitelist)
uci commit chilli

#uci set wireless.default_radio0.ssid=$(uci get zaytech.@node[0].guest_essid)
#uci set wireless.default_radio1.ssid=$(uci get zaytech.@node[0].guest_essid)
uci set wireless.default_radio0.ssid="$(uci get zaytech.@node[0].guest_essid)"
uci set wireless.default_radio1.ssid="$(uci get zaytech.@node[0].guest_essid)"
uci set wireless.radio0.disabled=0
uci set wireless.radio1.disabled=0
uci commit wireless
sh update.sh
reboot
