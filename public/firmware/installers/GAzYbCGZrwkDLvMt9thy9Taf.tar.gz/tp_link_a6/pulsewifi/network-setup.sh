
uci add firewall rule
uci set firewall.@rule[-1].name='Allow-SSH'
uci set firewall.@rule[-1].target='ACCEPT'
uci set firewall.@rule[-1].src='wan'
uci set firewall.@rule[-1].dest_port='22'
uci set firewall.@rule[-1].proto='tcp'
uci set firewall.@rule[-1].family='ipv4'

uci add firewall rule
uci set firewall.@rule[-1]=rule
uci set firewall.@rule[-1].name='Allow-Luci'
uci set firewall.@rule[-1].target='ACCEPT'
uci set firewall.@rule[-1].src='wan'
uci set firewall.@rule[-1].dest_port='80'
uci set firewall.@rule[-1].proto='tcp'
uci set firewall.@rule[-1].family='ipv4'

uci commit firewall

uci del network.lan.ip6assign
#uci set network.lan.ipaddr='172.22.100.1'
uci commit network

uci del dhcp.lan.start
uci del dhcp.lan.limit
uci del dhcp.lan.leasetime
uci del dhcp.lan.ra
uci del dhcp.lan.dhcpv6
uci set dhcp.lan.ignore='1'

uci commit dhcp
uci set wireless.default_radio0.ssid='Pulse WiFi'
uci set wireless.default_radio1.ssid='Pulse WiFi-5G'
uci set wireless.radio0.disabled='0'
uci set wireless.radio1.disabled='0'
uci commit wireless


echo ""
echo ""
echo ""
echo "Updating Pulse WiFi Settings now"
echo ""
echo ""
echo ""
echo ""
echo ""

/etc/init.d/chilli enable
sh /etc/pulsewifi/push-heartbeat.sh
