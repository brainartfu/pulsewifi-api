api=$(uci get pulsewifi.@config[0].api)
location_id=$(uci get pulsewifi.@config[0].location)
key=$(uci get pulsewifi.@config[0].key)
pdoa=$(uci get pulsewifi.@config[0].pdoa)
secret=$(uci get pulsewifi.@config[0].secret)
i=0
echo $i
i=$((i+1))

wifiResponse=$(curl --location --request GET "https://$api/api/wifi_router/settings/$key/$secret")
wifiSettings=$(echo $wifiResponse | jq -r '.network_settings')
nodeSettings=$(echo $wifiResponse | jq -r '.wifirouter')
echo $i
i=$((i+1))

essid=$(echo $wifiSettings | jq -r '.guestEssid')
config_version=$(echo $nodeSettings | jq -r '.config_version')
update_file=$(echo $wifiSettings | jq -r '.update_file')
update_file_hash=$(echo $wifiSettings | jq -r '.update_file_hash'|sed 's/ //g')
timezone=$(echo $wifiSettings | jq -r '.timezone'|sed 's/ //g')
radius_server=$(echo $wifiSettings | jq -r '.radius_server'|sed 's/ //g')
radius_secret=$(echo $wifiSettings | jq -r '.radius_secret'|sed 's/ //g')
domain=$(echo $wifiSettings | jq -r '.domain'|sed 's/ //g')
login_url=$(echo $wifiSettings | jq -r '.login_url'|sed 's/ //g')
dns1=$(echo $wifiSettings | jq -r '.dns1'|sed 's/ //g')
dns2=$(echo $wifiSettings | jq -r '.dns2'|sed 's/ //g')
whitelist=$(echo $wifiSettings | jq -r '.domain'|sed 's/ //g')
domainWhitelist=$(echo $wifiSettings | jq -r '.domainWhitelist'|sed 's/ //g')
echo $i
i=$((i+1))
old_config_version=$(uci get pulsewifi.@config[0].config_version)
old_essid=$(uci get pulsewifi.@config[0].essid)
old_radius_server=$(uci get pulsewifi.@config[0].radius_server)
old_radius_secret=$(uci get pulsewifi.@config[0].radius_secret)
old_login_url=$(uci get pulsewifi.@config[0].login_url)
old_dns1=$(uci get pulsewifi.@config[0].dns1)
old_dns2=$(uci get pulsewifi.@config[0].dns2)
old_domain=$(uci get pulsewifi.@config[0].domain)
old_whitelist=$(uci get pulsewifi.@config[0].whitelist)
old_domainWhitelist=$(uci get pulsewifi.@config[0].domainWhitelist)
echo $i
i=$((i+1))
old_update_file=$(uci get pulsewifi.@config[0].update_file)
old_update_file_hash=$(uci get pulsewifi.@config[0].update_file_hash| sed 's/ //g')
echo $i
i=$((i+1))
old_timezone=$(uci get pulsewifi.@config[0].timezone)
echo $i
i=$((i+1))
doReboot="0"

if [ "$timezone" != "$old_timezone" ]
then
    echo "Timezone needs to be updated"
    uci set pulsewifi.@config[0].timezone="$timezone"
    if [ "$timezone" == "1" ]
    then
        uci del system.ntp.enabled
        uci del system.ntp.enable_server
        uci set system.cfg01e48a.zonename='America/Los Angeles'
        uci set system.cfg01e48a.timezone='PST8PDT,M3.2.0,M11.1.0'
        uci set system.cfg01e48a.log_proto='udp'
        uci set system.cfg01e48a.conloglevel='8'
        uci set system.cfg01e48a.cronloglevel='5'
    fi
    uci commit system
    doReboot="1"
fi
echo $i
i=$((i+1))
if [ "$config_version" != "$old_config_version" ]
then
    echo "config_version needs to be updated"
    uci set pulsewifi.@config[0].config_version="$config_version"
    doReboot="1"
fi
echo $i
i=$((i+1))

if [ "$domain" != "$old_domain" ]
then
    echo "config_version needs to be updated"
    uci set pulsewifi.@config[0].domain="$domain"
    doReboot="1"
fi
echo $i
i=$((i+1))

if [ "$essid" != "$old_essid" ]
then
        echo "guestEssid needs to be updated"
        uci set pulsewifi.@config[0].essid="$essid"
        uci set wireless.default_radio0.ssid="$essid"
        uci set wireless.default_radio1.ssid="$essid"
        uci set wireless.default_radio0.encryption='none'
        uci set wireless.default_radio1.encryption='none'
        doReboot="1"
fi
echo $i
i=$((i+1))

if [ "$radius_server" != "$old_radius_server" ]
then
        echo "guestEssid needs to be updated"
        uci set pulsewifi.@config[0].radius_server="$radius_server"
        doReboot="1"
fi
echo $i
i=$((i+1))

if [ "$radius_secret" != "$old_radius_secret" ]
then
        echo "guestEssid needs to be updated"
        uci set pulsewifi.@config[0].radius_secret="$radius_secret"
        doReboot="1"
fi
echo $i
i=$((i+1))

if [ "$login_url" != "$old_login_url" ]
then
        echo "guestEssid needs to be updated"
        uci set pulsewifi.@config[0].login_url="$login_url"
        doReboot="1"
fi
echo $i
i=$((i+1))

if [ "$dns1" != "$old_dns1" ]
then
        echo "guestEssid needs to be updated"
        uci set pulsewifi.@config[0].dns1="$dns1"
        doReboot="1"
fi
echo $i
i=$((i+1))

if [ "$dns2" != "$old_dns2" ]
then
        echo "guestEssid needs to be updated"
        uci set pulsewifi.@config[0].dns2="$dns2"
        doReboot="1"
fi
echo $i
i=$((i+1))

if [ "$whitelist" != "$old_whitelist" ]
then
        echo "guestEssid needs to be updated"
        uci set pulsewifi.@config[0].whitelist="$whitelist"
        doReboot="1"
fi
echo $i
i=$((i+1))

if [ "$domainWhitelist" != "$old_domainWhitelist" ]
then
        echo "guestEssid needs to be updated"
        uci set pulsewifi.@config[0].domainWhitelist="$domainWhitelist"
        doReboot="1"
fi
echo $i
i=$((i+1))

echo "2"
                                                                             
if [ "$update_file_hash" != "$old_update_file_hash" ]                               
then                                                                                
    echo "Execute update file"
    updateURL="https://$api_url/firmware/updates/$update_file"
    cd /tmp
    rm $update_file
    wget $updateURL
    md5_of_file=$(md5sum $update_file|sed 's/ //g')
                                                                                    
    if [ "$md5_of_file" == "$update_file_hash" ]                                
    then                                                                        
        echo "MD5 matched $update_file"
        uci set pulsewifi.@config[0].update_file_hash="$update_file_hash"
        uci set pulsewifi.@config[0].update_file="$update_file"                         
        sh $update_file
        doReboot="1"                                 
    fi                                                                          
fi                                                                                  
echo $i
i=$((i+1))
                                                                                    
uci commit pulsewifi                                                                 
if [ "$doReboot" == "1" ]                                                           
then    
    # uci set pulsewifi.@config[0].dns1="8.8.8.8"
    # uci set pulsewifi.@config[0].dns2="8.8.4.4"

    uci commit pulsewifi
    echo $i
    i=$((i+1))

    uci set chilli.@chilli[0].radiusserver1=$(uci get pulsewifi.@config[0].radius_server)
    uci set chilli.@chilli[0].radiusserver2=$(uci get pulsewifi.@config[0].radius_server)
    uci set chilli.@chilli[0].radiussecret=$(uci get pulsewifi.@config[0].radius_secret)
    uci set chilli.@chilli[0].uamserver=http://$(uci get pulsewifi.@config[0].domain)$(uci get pulsewifi.@config[0].login_url)
    #uci set chilli.@chilli[0].uamsecret=$(uci get pulsewifi.@config[0].uam_secret)
    uci set chilli.@chilli[0].uamsecret=''
    uci set chilli.@chilli[0].dns1=$(uci get pulsewifi.@config[0].dns1)
    uci set chilli.@chilli[0].dns2=$(uci get pulsewifi.@config[0].dns2)
    uci set chilli.@chilli[0].radiusnasid=$(uci get pulsewifi.@config[0].nasid)
    uci set chilli.@chilli[0].uamallowed=$(uci get pulsewifi.@config[0].whitelist)
    uci set chilli.@chilli[0].dns1=$(uci get pulsewifi.@config[0].dns1)
    uci set chilli.@chilli[0].dns2=$(uci get pulsewifi.@config[0].dns2)
    uci set chilli.@chilli[0].uamdomain=$(uci get pulsewifi.@config[0].domainWhitelist)
    #uci set chilli.@chilli[0].uamhomepage=$(uci get pulsewifi.@config[0].domainWhitelist)
    uci commit chilli
    echo $i
    i=$((i+1))
    #uci set wireless.default_radio0.ssid=$(uci get pulsewifi.@config[0].guest_essid)
    #uci set wireless.default_radio1.ssid=$(uci get pulsewifi.@config[0].guest_essid)
    uci set wireless.default_radio0.ssid="$(uci get pulsewifi.@config[0].essid)"
    uci set wireless.default_radio1.ssid="$(uci get pulsewifi.@config[0].essid)"
    uci set wireless.radio0.disabled=0
    uci set wireless.radio1.disabled=0
    echo $i
    i=$((i+1))
    /etc/init.d/cron start                                                                       
    uci commit wireless                                                         
    uci commit system                                                         
    echo "Rebooting device"                                                     
    #reboot                                                                      
fi    