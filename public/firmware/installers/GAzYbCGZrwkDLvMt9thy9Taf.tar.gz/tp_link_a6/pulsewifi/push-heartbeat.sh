api=$(uci get pulsewifi.@config[0].api)
key=$(uci get pulsewifi.@config[0].key)
local_secret=$(uci get pulsewifi.@config[0].secret)
zero=""
#version=$(uci get pulsewifi.@node[0].config_version)

#version=$(wget -qO- "http://$api/api/location/wifi-routers/firmware/heartbeat/$key/$local_secret")

## Step 1
## Get Config Verison as per location id and enterprise id
heartbeat=$(curl --location --request GET "https://$api/api/wifi_router/heartbeat/$key/$local_secret")
success=$(echo $heartbeat | jq -r '.success')

if [ "$success" = true ] ; then
        data=$(echo $heartbeat | jq -r '.data')
        secret=$(echo $data | jq -r '.secret')
	if [ "$secret" = "$local_secret" ] ; then
		## Step 2
		## Ensure config version is numeric
		config_version=$(echo $data | jq -r '.config_version')

		#re='^[0-9]+$'
		#if ! [[ $config_version =~ $re ]] ; then
		#	echo "error: Not a number" >&2; exit 1
		#fi

		case $config_version in
                    ''|*[!0-9]*) exit 1 ;;
                    *) echo "config is good" ;;
                esac

		## Step 3
		## Compare config version with local version
		## If mismatch download settings and update itself

		local_config_version=$(uci get pulsewifi.@node[0].config_version)

		if [ "$local_config_version" != "$config_version" ]
		then
			echo "New config verison is different. Downloading all settings and updating."
			sh /etc/pulsewifi/update-pulse.sh
		else
			echo "New config and old config are same. Nothing to do here!"
		fi
	else
		echo "WiFi Router Secret verification failed"
	fi
else
	echo "API returned false"
fi